package model;

public class Poupanca extends Conta{
    
}
