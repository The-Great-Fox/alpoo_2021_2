package model;

public abstract class Conta implements Regras{
    private String nome;
    private int agencia;
    private int conta;
    private double saldo;

    public String getNome() {
        return nome;
    }

    public Conta(String nome, int agencia, int conta) {
        //this.nome = nome;
        //this.agencia = agencia;
        //this.conta = conta;
        this.setNome(nome);
        this.setAgencia(agencia);
        this.setConta(conta);
        this.setSaldo(0);
    }
  
    public Conta(){
        
    }
    
    public void setNome(String nome) {
        if (nome.length() >=3){
            this.nome = nome;
        }
        else{
            System.out.println("Nome da conta deve ter ao menos 3 caracteres");
        }
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public void depositar(double valor){
        if (valor >0){
            this.setSaldo(this.saldo + valor);
        }
        else
        {
            System.out.println("Valor do deposito deve ser maior que zero");
        }
    }
}
