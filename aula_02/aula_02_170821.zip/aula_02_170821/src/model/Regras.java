package model;

public interface Regras {
    public void Sacar(double valor);
}
