package controller;

import model.Conta;

public class Principal {
    public static void main(String[] args) {
        
        
        //Conta obj_conta = new Conta("It",11111,22222);
        /*
        //obj_conta.setNome("It");
        System.out.println(obj_conta.getNome());
        System.out.println(obj_conta.getAgencia());
        System.out.println(obj_conta.getConta());
        */
    }
}
